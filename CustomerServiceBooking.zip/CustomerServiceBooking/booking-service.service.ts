import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BookingServiceService {
  baseUrl="http://localhost:8081"
  constructor(private _http:HttpClient) { }
  getBooking(){
    return this._http.get(`${this.baseUrl}/ Booking`)
  }
  getBookingByUsername(userName: string) {
    return this._http.get(`${this.baseUrl}/Booking/${userName}`);
  }
  addBooking(data:any){
    console.log(data);
    console.log(data);
    // return this._http.post(`${this.baseUrl}/addBooking`,custInfo,serviceInfo)
    return this._http.post(`${this.baseUrl}/Booking`,data)
  }
}
